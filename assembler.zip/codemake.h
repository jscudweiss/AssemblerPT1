//
// Created by jscud on 3/8/2022.
//

#ifndef ASSEMBLER_CODEMAKE_H
#define ASSEMBLER_CODEMAKE_H

#endif //ASSEMBLER_CODEMAKE_H

void collectVar(char *inputString, char *inputType);
int getCode(int outCom[16]);
void freeVals();