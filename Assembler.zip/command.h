//
// Created by jscud on 3/2/2022.
//

#ifndef ASSEMBLER_COMMAND_H
#define ASSEMBLER_COMMAND_H

char* commandType(const char comm[200]);

#endif //ASSEMBLER_COMMAND_H
