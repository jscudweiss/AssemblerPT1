//
// Created by jscud on 3/2/2022.
//

#ifndef ASSEMBLER_READER_H
#define ASSEMBLER_READER_H

void loadFile(char *filePath);
void readLine(char *curLine);

#endif //ASSEMBLER_READER_H
