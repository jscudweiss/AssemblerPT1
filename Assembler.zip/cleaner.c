//
// Created by jscud on 3/2/2022.
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define MAX_LEN 200

void cleanLine(char *inputString, char *cleanedLine) {
    int slash = 1;
    while (*inputString != '\0' && slash == 1) {
        switch (*inputString) {
            case ' ':
                break;
            case '\n':
                break;
            case '/':
                switch (*(inputString + 1)) {
                    case '/':
                        slash = 0;
                        break;
                    default:
                        break;
                }
                break;
            default:
                *cleanedLine = *inputString;
                cleanedLine++;
        }
        inputString++;
    }
    *cleanedLine = '\0';
}