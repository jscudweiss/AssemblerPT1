//
// Created by jscud on 2/27/2022.
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "command.h"
#include "Reader.h"
#include "cleaner.h"

#define MAX_LEN 200


//read Input



//Clean up Line







//main method
int main(int argc, char** argv) {
    char* args = argv[1];
    loadFile(args);
    char line[200];
    char cleanedLine[200];
    char * output;
    readLine(line);
    while (*line != '\0') {
        cleanLine(line, cleanedLine);
        output = commandType(cleanedLine);
        printf("%s", output);
        readLine(line);
    }
    free(output);
    return 0;
}
