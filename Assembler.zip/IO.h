//
// Created by jscud on 3/2/2022.
//

#ifndef ASSEMBLER_IO_H
#define ASSEMBLER_IO_H

#endif //ASSEMBLER_IO_H
void initFile(char **filePaths);
int readLine(char *curLine);
void writeLine(const char* line);
void endFile();
void cleanLine(char *inputString, char *cleanedLine);