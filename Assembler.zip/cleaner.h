//
// Created by jscud on 3/2/2022.
//

#ifndef ASSEMBLER_CLEANER_H
#define ASSEMBLER_CLEANER_H

void cleanLine(char *inputString, char *cleanedLine);

#endif //ASSEMBLER_CLEANER_H
